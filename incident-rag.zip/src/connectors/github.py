import re
from datetime import datetime
from pathlib import Path
from typing import Any

import frontmatter
import httpx
import yaml

from .base import BaseConnector, RawDocument, SourceType, ensure_utc, markdown_type

SECTIONS = ("code", "runbooks", "docs")
PR_NUMBER = re.compile(r"\(#(\d+)\)$")  # squash-merge commit titles end with the PR number: "Fix retries (#123)"


class GitHubConnector(BaseConnector):
    """Fetch what ``data/sources.yaml`` lists for the service under test.

    ``runbooks`` and ``docs`` entries: the Markdown file, or the Markdown files in the folder, at ``path``
    (types ``runbook`` and ``doc``).
    ``code`` entries: the latest commits on the default branch that touch ``path`` (type ``github``). With
    squash merges every commit is a merged PR whose message holds the PR description, so it is stored as the PR.
    """

    def __init__(self, sources_path: str | Path, token: str | None = None) -> None:
        self.sources_path = Path(sources_path)
        self.token = token

    async def fetch(self, since: datetime | None) -> list[RawDocument]:
        sources = self._load_sources()
        if not any(sources.values()):
            return []

        since = ensure_utc(since) if since is not None else None
        headers = {"Accept": "application/vnd.github+json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        documents: list[RawDocument] = []
        transport = httpx.AsyncHTTPTransport(retries=3)  # retries failed connections, not HTTP errors
        async with httpx.AsyncClient(base_url="https://api.github.com", headers=headers, timeout=30.0,
                                     transport=transport) as client:
            for section, doc_type in (("runbooks", "runbook"), ("docs", "doc")):
                for entry in sources[section]:
                    documents += await self._markdown_files(client, entry["repo"], entry.get("path", ""), doc_type, since)
            for entry in sources["code"]:
                documents += await self._commits(client, entry["repo"], entry.get("path", ""), since)
        return documents

    def _load_sources(self) -> dict[str, list[dict[str, str]]]:
        if not self.sources_path.exists():
            return {section: [] for section in SECTIONS}
        data = yaml.safe_load(self.sources_path.read_text(encoding="utf-8")) or {}
        return {section: data.get(section) or [] for section in SECTIONS}

    async def _markdown_files(
        self, client: httpx.AsyncClient, repo: str, path: str, doc_type: SourceType, since: datetime | None
    ) -> list[RawDocument]:
        info = await self._get_json(client, f"/repos/{repo}")
        branch = info["default_branch"]
        pushed_at = self._parse_datetime(info["pushed_at"])
        if since is not None and pushed_at <= since:
            return []  # nothing pushed since the last ingest

        tree = await self._get_json(client, f"/repos/{repo}/git/trees/{branch}", params={"recursive": "1"})
        prefix = path.strip("/")
        files = [
            item["path"] for item in tree.get("tree", [])
            if item["type"] == "blob" and item["path"].endswith(".md")
            and (not prefix or item["path"] == prefix or item["path"].startswith(prefix + "/"))
        ]

        documents: list[RawDocument] = []
        for file in files:
            response = await client.get(f"https://raw.githubusercontent.com/{repo}/{branch}/{file}")
            response.raise_for_status()
            try:
                post = frontmatter.loads(response.text)
                metadata, text = dict(post.metadata), post.content.strip()
            except Exception:  # front matter we can't parse (e.g. TOML): keep the whole file as text
                metadata, text = {}, response.text.strip()
            if not text:
                continue
            documents.append(RawDocument(
                doc_id=f"github:{repo}/{file}",
                source_type=markdown_type(metadata, doc_type),
                source_uri=f"https://github.com/{repo}/blob/{branch}/{file}",
                title=str(metadata.get("title") or Path(file).stem),
                raw_text=text,
                updated_at=pushed_at,
                author=repo.split("/")[0],
                metadata=metadata,
            ))
        return documents

    async def _commits(
        self, client: httpx.AsyncClient, repo: str, path: str, since: datetime | None
    ) -> list[RawDocument]:
        params: dict[str, Any] = {"per_page": 50}
        if path:
            params["path"] = path.strip("/")
        if since is not None:
            params["since"] = since.isoformat()
        commits = await self._get_json(client, f"/repos/{repo}/commits", params=params)

        documents: list[RawDocument] = []
        for item in commits:
            commit = item["commit"]
            committed_at = self._parse_datetime(commit["committer"]["date"])
            # Merge commits repeat their PR; bot commits are dependency bumps
            if len(item.get("parents", [])) > 1 or (item.get("author") or {}).get("type") == "Bot":
                continue
            if since is not None and committed_at <= since:
                continue
            title = commit["message"].splitlines()[0]
            pr = PR_NUMBER.search(title)
            documents.append(RawDocument(
                doc_id=f"github:{repo}/pull/{pr.group(1)}" if pr else f"github:{repo}/commit/{item['sha'][:12]}",
                source_type="github",
                source_uri=f"https://github.com/{repo}/pull/{pr.group(1)}" if pr else item["html_url"],
                title=title,
                raw_text=commit["message"].strip(),
                updated_at=committed_at,
                author=commit["author"].get("name", "unknown"),
                # A squash-merged PR counts as a merged PR (tier A); a plain commit is tier B
                metadata={"kind": "pr", "pr_merged": True} if pr else {"kind": "commit"},
            ))
        return documents

    async def _get_json(self, client: httpx.AsyncClient, url: str, params: dict[str, Any] | None = None) -> Any:
        response = await client.get(url, params=params)
        response.raise_for_status()
        return response.json()

    def _parse_datetime(self, raw_value: str) -> datetime:
        # GitHub datetime format: 2026-10-16T12:34:09Z
        return ensure_utc(datetime.fromisoformat(raw_value.replace("Z", "+00:00")))
