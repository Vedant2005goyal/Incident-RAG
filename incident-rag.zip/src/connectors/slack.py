from datetime import UTC, datetime

import httpx

from .base import BaseConnector, RawDocument, ensure_utc


class SlackConnector(BaseConnector):
    """Fetches threads (a message with replies) from Slack channels."""

    def __init__(self, bot_token: str | None, channel_ids: list[str] | None = None) -> None:
        self.bot_token = bot_token
        self.channel_ids = channel_ids or []  # empty: every public channel

    async def fetch(self, since: datetime | None) -> list[RawDocument]:
        if not self.bot_token:
            return []
        headers = {"Authorization": f"Bearer {self.bot_token}"}
        documents: list[RawDocument] = []

        async with httpx.AsyncClient(base_url="https://slack.com/api", headers=headers) as client:
            if self.channel_ids:
                channels = [{"id": channel_id} for channel_id in self.channel_ids]
            else:
                data = await self._get(client, "/conversations.list", {"types": "public_channel", "limit": 100})
                channels = data.get("channels", [])

            for channel in channels:
                channel_id = channel["id"]
                channel_name = channel.get("name", channel_id)
                params = {"channel": channel_id, "limit": 100}
                if since is not None:
                    params["oldest"] = str(ensure_utc(since).timestamp())
                history = await self._get(client, "/conversations.history", params)

                for message in history.get("messages", []):
                    if message.get("thread_ts") != message["ts"]:
                        continue  # not the start of a thread
                    thread_ts = message["ts"]
                    replies = await self._get(client, "/conversations.replies", {"channel": channel_id, "ts": thread_ts})
                    messages = [{"user": m.get("user", "unknown"), "text": m.get("text", "")}
                                for m in replies.get("messages", [])]
                    if not messages:
                        continue
                    documents.append(RawDocument(
                        doc_id=f"slack-{channel_id}-{thread_ts}",
                        source_type="slack",
                        source_uri=f"slack://channel/{channel_id}/thread/{thread_ts}",
                        title=f"Slack Thread in {channel_name}",
                        raw_text="\n".join(f"{m['user']}: {m['text']}" for m in messages),
                        updated_at=datetime.fromtimestamp(float(replies["messages"][-1]["ts"]), tz=UTC),
                        author=messages[0]["user"],
                        metadata={"channel": channel_name, "messages": messages},  # parse() builds a SlackThread from these
                    ))
        return documents

    async def _get(self, client: httpx.AsyncClient, path: str, params: dict) -> dict:
        """GET a Slack API method; an error reply ({"ok": false}) counts as no data."""
        response = await client.get(path, params=params)
        response.raise_for_status()
        data = response.json()
        return data if data.get("ok") else {}
