from datetime import UTC, datetime
from pathlib import Path

import frontmatter

from .base import BaseConnector, RawDocument, ensure_utc, markdown_type

# The first folder under data/docs/ sets a file's type; anything else is technical documentation
FOLDER_TYPES = {"postmortems": "postmortem", "runbooks": "runbook"}


class LocalFileConnector(BaseConnector):
    """Reads the Markdown files (with front matter) under the docs folder."""

    def __init__(self, docs_path: str | Path = "data/docs") -> None:
        self.docs_path = Path(docs_path)

    async def fetch(self, since: datetime | None) -> list[RawDocument]:
        if not self.docs_path.exists():
            return []
        documents = [self._read(path) for path in sorted(self.docs_path.rglob("*.md"))]
        if since is not None:
            documents = [doc for doc in documents if doc.updated_at > ensure_utc(since)]
        return documents

    def _read(self, path: Path) -> RawDocument:
        post = frontmatter.load(path)
        metadata = dict(post.metadata)
        folder = path.relative_to(self.docs_path).parts[0]

        updated_at = metadata.get("updated_at")
        if isinstance(updated_at, str):
            updated_at = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
        if not isinstance(updated_at, datetime):  # not given (or a bare date): use the file's modification time
            updated_at = datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)

        return RawDocument(
            doc_id=str(metadata.get("doc_id") or path.stem),
            source_type=markdown_type(metadata, FOLDER_TYPES.get(folder, "doc")),
            source_uri=str(metadata.get("source_uri") or path.name),
            title=str(metadata.get("title") or path.stem),
            raw_text=post.content.strip(),
            updated_at=ensure_utc(updated_at),
            author=str(metadata.get("author") or "unknown"),
            metadata=metadata,
        )
